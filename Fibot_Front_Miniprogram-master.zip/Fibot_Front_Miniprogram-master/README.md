# Fibot_Front_Miniprogram
Miniprogram front end for financial robot(Fibot)
