// pages/application/sellBill/sellBill.js
const app = getApp()
const util = require('../../../utils/util.js')
const host = app.globalData.requestHost

const initPage = function(page){
  let date = util.getcurDateFormatString(new Date())
  // 清除buyInfo缓存
  wx.removeStorage({
    key: 'buyInfo',
    success: function(res) {
      console.log('清理buyInfo缓存:')
      console.log(res)
    },
    fail: err => {
      console.log('清理buyInfo缓存失败:')
      console.error(err)
    }
  })
  // 设置日期属性
  page.setData({
    date: date
  })
}

Page({

  /**
   * 页面的初始数据
   */
  data: {
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    initPage(this)
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },

  DateChange(e) {
    this.setData({
      date: e.detail.value
    })
  },

  addCustomer: function(e) {
    wx.navigateTo({
      url: '../customerList/customerList?back=sell',
    })
  },

  addGoods: function(e) {
    // 缓存记录已买的商品
    try { 
      wx.setStorageSync('buyInfo', 
      {
        list: this.data.buyList,
        total: this.data.total
      })
    } catch(e) {console.error(e)}
    wx.navigateTo({
      url: '../chooseGood/chooseGood?back=sell',
    })
  },

  submitBill: function(e) {
    let that = this
    let slist = this.data.buyList
    if(!slist || slist.length==0)
      return

    // 处理前端销售单数据，发送给后台
    let goodsList = []
    for(let i in slist){
      goodsList.push({
        goodsId: slist[i].id,
        number: slist[i].buyNum
      })
    }
    console.log(app.globalData)
    console.log(goodsList)
    wx.request({
      url: host+'/addSell',
      method: 'POST',
      header: {
        "Content-Type": 'application/json'
      },
      data: JSON.stringify({
        companyId: app.globalData.companyId,
        customerId: that.data.customer.id,
        date: that.data.date,
        sumprice: that.data.total,
        goodsList: goodsList
      }),
      success: res => {
        console.log(res)
        wx.showModal({
          title: '成功',
          content: '订单提交成功',
          confirmText: '确认',
          showCancel: false,
          success: res => {
            if(res.confirm){
              wx.redirectTo({
                url: '/pages/index/index',
              })
            }
          }
        })
      }
    })
  },

  // 取消订单，回到首页
  cancelBill() {
    wx.redirectTo({
      url: '/pages/index/index',
    })
  }
})